const app = Vue.createApp({
    data() {
        return {
            cart: [],
            menuItems: [],
            category: ''
        }
    },
    methods: {
        loadItems() {
            fetch('project.json')
                .then(response => response.json())
                .then(data => {
                    this.menuItems = data.menu[this.category];
                })
                .catch(error => console.error('Error fetching menu:', error));
        },
        addToCart(item) {
            this.cart.push(item);
            this.updateSummary();
        },
        updateSummary() {
            const cartItems = document.getElementById("cartItems");
            cartItems.innerHTML = "";
            this.cart.forEach(item => {
                const li = document.createElement("li");
                li.textContent = item.name;
                cartItems.appendChild(li);
            });
        },
        placeOrder() {
            localStorage.setItem("cart", JSON.stringify(this.cart));
            window.location.href = "checkout.html";
        }
    },
    mounted() {
        setInterval(() => {
            //  elapsed time every second
            this.elapsedTime++;
        }, 1000);
    },
    computed: {
        elapsedTime() {
            //  elapsed time in minutes and seconds
            const minutes = Math.floor(this.elapsedTime / 60);
            const seconds = this.elapsedTime % 60;
            return `${minutes}m ${seconds}s`;
        }
    }
});

app.mount('#app');