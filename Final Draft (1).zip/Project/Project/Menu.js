import React, { useState } from 'react';
import './styles.css'; //  CSS file  

const Menu = ({ menuData }) => {
  const [cart, setCart] = useState([]);
  const [showSummary, setShowSummary] = useState(false);

  // Function to add item to cart
  const addToCart = (item) => {
    setCart([...cart, item]);
    setShowSummary(true); // Show summary when item is added to cart
  };

  return (
    <div className="menu-container">
      <h1>Restaurant Menu</h1>
      <div className="menu">
        {Object.keys(menuData).map((category) => (
          <div key={category} className="category">
            <h2>{category}</h2>
            {menuData[category].map((item) => (
              <div key={item.name} className="item">
                <h3>{item.name}</h3>
                <p>{item.description}</p>
                <img src={item.image} alt={item.name} />
                <button onClick={() => addToCart(item)}>Add to Cart</button>
              </div>
            ))}
          </div>
        ))}
      </div>
      {showSummary && (
        <div className="summary">
          <h2>Summary</h2>
          <ul>
            {cart.map((item, index) => (
              <li key={index}>{item.name}</li>
            ))}
          </ul>
          <button onClick={() => setShowSummary(false)}>Close</button>
        </div>
      )}
    </div>
  );
};

export default Menu;
