document.addEventListener("DOMContentLoaded", function () {
    const movieSelect = document.getElementById("movieSelect");
    const movieInfo = document.getElementById("movieInfo");
    const poster = document.getElementById("poster");
    const trailer = document.getElementById("trailer");

    fetch("Potter.json")
        .then(response => response.json())
        .then(data => {
            data.films.forEach(movie => {
                const option = document.createElement("option");
                option.value = movie.title;
                option.textContent = movie.title;
                movieSelect.appendChild(option);
            });

            movieSelect.addEventListener("change", function () {
                const selectedMovie = movieSelect.value;
                const selectedMovieData = data.films.find(movie => movie.title === selectedMovie);

                movieInfo.innerHTML = `
                    <p><strong>Director:</strong> ${selectedMovieData.director}</p>
                    <p><strong>Writer:</strong> ${selectedMovieData.writer}</p>
                    <p><strong>Producer:</strong> ${selectedMovieData.producer}</p>
                    <p><strong>Music:</strong> ${selectedMovieData.music}</p>
                `;

                poster.src = selectedMovieData.image;

                trailer.src = `https://www.youtube.com/embed/${selectedMovieData.youtubecode}`;
            });
        })
        .catch(error => console.error("Error fetching data:", error));
});
